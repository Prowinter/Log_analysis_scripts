Changelog
---------

Version 0.3.3
~~~~~~~~~~~~~

- Fix the bug related to the pyserial encoding data with Python v3.x

Version 0.3.2
~~~~~~~~~~~~~

- Fix the bug related to the pyserial encoding data

Version 0.3
~~~~~~~~~~~

Released on 2012-06-29.

- Support for GSMLink with AT commands. GSMLink can use TCP, UDP or Serial link.

Version 0.2
~~~~~~~~~~~

Released on 2012-06-14.

* TCP and UDP Optimisations.
* Improve the python3 compatibility.
* Can use `Link.read()` with a specific timeout.

Version 0.1
~~~~~~~~~~~

Released on 2012-06-05.

* Support for TCP, UDP and Serial (with pyserial).
