# Master version for Pillow
__version__ = "10.0.1"
